import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

class GamesScreen extends StatefulWidget {
  const GamesScreen({super.key});
  @override
  State<GamesScreen> createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen> {
  int _activeGame = -1;
  @override
  Widget build(BuildContext context) {
    if (_activeGame == 0) return _MemoryGame(onBack: () => setState(() => _activeGame = -1));
    if (_activeGame == 1) return _MathGame(onBack: () => setState(() => _activeGame = -1));
    if (_activeGame == 2) return _NumberGame(onBack: () => setState(() => _activeGame = -1));
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [AppTheme.bgDark, Color(0xFF0D1230)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ألعاب الذكاء 🧠', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w800))
                    .animate().fadeIn(duration: 500.ms),
                const SizedBox(height: 8),
                Text('تحدى عقلك يومياً', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 14))
                    .animate().fadeIn(delay: 100.ms),
                const SizedBox(height: 24),
                _GameCard(title: 'لعبة الذاكرة', description: 'تذكر الأرقام وأعد ترتيبها', icon: Icons.grid_view_rounded, gradient: AppTheme.primaryGradient, onTap: () => setState(() => _activeGame = 0), delay: 200),
                const SizedBox(height: 14),
                _GameCard(title: 'الحساب السريع', description: 'احسب بسرعة قبل انتهاء الوقت', icon: Icons.calculate_rounded, gradient: AppTheme.accentGradient, onTap: () => setState(() => _activeGame = 1), delay: 300),
                const SizedBox(height: 14),
                _GameCard(title: 'خمّن الرقم', description: 'خمّن الرقم السري من 1 إلى 100', icon: Icons.casino_rounded, gradient: AppTheme.purpleGradient, onTap: () => setState(() => _activeGame = 2), delay: 400),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GameCard extends StatelessWidget {
  final String title, description;
  final IconData icon;
  final LinearGradient gradient;
  final VoidCallback onTap;
  final int delay;
  const _GameCard({required this.title, required this.description, required this.icon, required this.gradient, required this.onTap, required this.delay});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(22), border: Border.all(color: gradient.colors.first.withOpacity(0.3), width: 1)),
        child: Row(
          children: [
            Container(width: 56, height: 56, decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: Colors.white, size: 28)),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 17, fontWeight: FontWeight.w700)),
              Text(description, style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
            ])),
            const Icon(Icons.arrow_forward_ios_rounded, color: AppTheme.textSecondary, size: 16),
          ],
        ),
      ),
    ).animate().fadeIn(delay: Duration(milliseconds: delay), duration: 400.ms).slideX(begin: 0.2);
  }
}

// Memory Game
class _MemoryGame extends StatefulWidget {
  final VoidCallback onBack;
  const _MemoryGame({required this.onBack});
  @override
  State<_MemoryGame> createState() => _MemoryGameState();
}

class _MemoryGameState extends State<_MemoryGame> {
  List<int> _sequence = [];
  List<int> _userInput = [];
  bool _showing = false;
  int _showingIndex = -1;
  int _score = 0;
  bool _failed = false;
  bool _waiting = false;

  @override
  void initState() { super.initState(); _startRound(); }

  void _startRound() {
    final rng = Random();
    _sequence = List.generate(_score + 3, (_) => rng.nextInt(9));
    _userInput = []; _failed = false; _waiting = false;
    _showSequence();
  }

  Future<void> _showSequence() async {
    setState(() => _showing = true);
    for (int i = 0; i < _sequence.length; i++) {
      await Future.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      setState(() => _showingIndex = _sequence[i]);
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      setState(() => _showingIndex = -1);
    }
    if (!mounted) return;
    setState(() { _showing = false; _waiting = true; });
  }

  void _onTap(int n) {
    if (_showing || !_waiting || _failed) return;
    setState(() {
      _userInput.add(n);
      final idx = _userInput.length - 1;
      if (_userInput[idx] != _sequence[idx]) { _failed = true; _score = 0; }
      else if (_userInput.length == _sequence.length) { _score++; Future.delayed(const Duration(milliseconds: 600), _startRound); }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppTheme.bgDark, Color(0xFF0D1230)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Row(children: [
            IconButton(onPressed: widget.onBack, icon: const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.textPrimary)),
            Text('لعبة الذاكرة', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w700)),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(gradient: AppTheme.primaryGradient, borderRadius: BorderRadius.circular(12)),
              child: Text('النقاط: $_score', style: GoogleFonts.cairo(color: Colors.white, fontWeight: FontWeight.w700))),
          ]),
          const SizedBox(height: 20),
          Text(_failed ? 'خطأ! 😢 اضغط للمحاولة مجدداً' : _showing ? 'تذكر التسلسل...' : 'أدخل التسلسل',
              style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 15), textAlign: TextAlign.center),
          const SizedBox(height: 30),
          GridView.count(
            crossAxisCount: 3, shrinkWrap: true, crossAxisSpacing: 12, mainAxisSpacing: 12,
            children: List.generate(9, (i) {
              final isH = _showingIndex == i;
              return GestureDetector(
                onTap: _failed ? _startRound : () => _onTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  decoration: BoxDecoration(
                    gradient: isH ? AppTheme.primaryGradient : null,
                    color: isH ? null : AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: isH ? [BoxShadow(color: AppTheme.primary.withOpacity(0.5), blurRadius: 16)] : null,
                  ),
                  child: Center(child: Text('${i + 1}', style: GoogleFonts.cairo(color: isH ? Colors.white : AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w700))),
                ),
              );
            }),
          ),
          const SizedBox(height: 20),
          Text('التقدم: ${_userInput.length}/${_sequence.length}', style: GoogleFonts.cairo(color: AppTheme.primary, fontSize: 14)),
        ]))),
      ),
    );
  }
}

// Math Game
class _MathGame extends StatefulWidget {
  final VoidCallback onBack;
  const _MathGame({required this.onBack});
  @override
  State<_MathGame> createState() => _MathGameState();
}

class _MathGameState extends State<_MathGame> {
  final _rng = Random();
  int _a = 0, _b = 0, _answer = 0, _score = 0, _timeLeft = 15;
  String _op = '+';
  bool _gameOver = false;
  Timer? _timer;
  final _ctrl = TextEditingController();

  @override
  void initState() { super.initState(); _newQuestion(); _startTimer(); }

  void _newQuestion() {
    _a = _rng.nextInt(20) + 1; _b = _rng.nextInt(20) + 1;
    final ops = ['+', '-', '×']; _op = ops[_rng.nextInt(3)];
    _answer = _op == '+' ? _a + _b : _op == '-' ? _a - _b : _a * _b;
    _ctrl.clear();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() { _timeLeft--; if (_timeLeft <= 0) { _gameOver = true; _timer?.cancel(); } });
    });
  }

  void _check() {
    final val = int.tryParse(_ctrl.text);
    if (val == null) return;
    if (val == _answer) setState(() { _score++; _timeLeft = (_timeLeft + 5).clamp(0, 30); _newQuestion(); });
  }

  void _restart() {
    setState(() { _score = 0; _timeLeft = 15; _gameOver = false; _newQuestion(); });
    _startTimer();
  }

  @override
  void dispose() { _timer?.cancel(); _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppTheme.bgDark, Color(0xFF0D1230)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Row(children: [
            IconButton(onPressed: widget.onBack, icon: const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.textPrimary)),
            Text('الحساب السريع', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w700)),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(gradient: AppTheme.accentGradient, borderRadius: BorderRadius.circular(12)),
              child: Text('$_score نقطة', style: GoogleFonts.cairo(color: Colors.white, fontWeight: FontWeight.w700))),
          ]),
          const SizedBox(height: 30),
          if (_gameOver) ...[
            const Icon(Icons.emoji_events_rounded, color: AppTheme.gold, size: 80),
            const SizedBox(height: 16),
            Text('انتهت اللعبة!', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('نتيجتك: $_score نقطة', style: GoogleFonts.cairo(color: AppTheme.gold, fontSize: 20)),
            const SizedBox(height: 30),
            ElevatedButton(onPressed: _restart, style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text('العب مجدداً', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700))),
          ] else ...[
            Stack(alignment: Alignment.center, children: [
              SizedBox(width: 80, height: 80, child: CircularProgressIndicator(value: _timeLeft / 15, backgroundColor: AppTheme.bgCard, valueColor: AlwaysStoppedAnimation(_timeLeft > 8 ? AppTheme.secondary : AppTheme.accent), strokeWidth: 6)),
              Text('$_timeLeft', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 30),
            Container(
              padding: const EdgeInsets.all(30),
              decoration: BoxDecoration(gradient: AppTheme.accentGradient, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: AppTheme.accent.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))]),
              child: Text('$_a $_op $_b = ?', style: GoogleFonts.cairo(color: Colors.white, fontSize: 40, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 24),
            TextField(controller: _ctrl, keyboardType: TextInputType.number, textAlign: TextAlign.center,
              style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w700),
              decoration: InputDecoration(hintText: 'الإجابة', hintStyle: GoogleFonts.cairo(color: AppTheme.textSecondary), filled: true, fillColor: AppTheme.bgCard, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
              onSubmitted: (_) => _check()),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _check,
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text('تأكيد', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700)))),
          ],
        ]))),
      ),
    );
  }
}

// Number Guess Game
class _NumberGame extends StatefulWidget {
  final VoidCallback onBack;
  const _NumberGame({required this.onBack});
  @override
  State<_NumberGame> createState() => _NumberGameState();
}

class _NumberGameState extends State<_NumberGame> {
  int _secret = Random().nextInt(100) + 1;
  int _attempts = 0;
  String _hint = 'خمّن رقماً من 1 إلى 100';
  bool _won = false;
  final _ctrl = TextEditingController();

  void _guess() {
    final val = int.tryParse(_ctrl.text);
    if (val == null) return;
    setState(() {
      _attempts++;
      if (val == _secret) { _won = true; _hint = 'صح! 🎉 الرقم كان $_secret'; }
      else if (val < _secret) { _hint = 'أكبر من $val ⬆️'; }
      else { _hint = 'أصغر من $val ⬇️'; }
    });
    _ctrl.clear();
  }

  void _restart() {
    setState(() { _secret = Random().nextInt(100) + 1; _attempts = 0; _hint = 'خمّن رقماً من 1 إلى 100'; _won = false; });
    _ctrl.clear();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppTheme.bgDark, Color(0xFF0D1230)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        child: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Row(children: [
            IconButton(onPressed: widget.onBack, icon: const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.textPrimary)),
            Text('خمّن الرقم', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w700)),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6), decoration: BoxDecoration(gradient: AppTheme.purpleGradient, borderRadius: BorderRadius.circular(12)),
              child: Text('$_attempts محاولة', style: GoogleFonts.cairo(color: Colors.white, fontWeight: FontWeight.w700))),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(30),
            decoration: BoxDecoration(gradient: AppTheme.purpleGradient, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: AppTheme.primary.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))]),
            child: Text(_won ? '🎉' : '🤔', style: const TextStyle(fontSize: 60)),
          ),
          const SizedBox(height: 24),
          Text(_hint, style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 18, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
          const SizedBox(height: 30),
          if (!_won) ...[
            TextField(controller: _ctrl, keyboardType: TextInputType.number, textAlign: TextAlign.center,
              style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w700),
              decoration: InputDecoration(hintText: '؟', hintStyle: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 24), filled: true, fillColor: AppTheme.bgCard, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
              onSubmitted: (_) => _guess()),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _guess,
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text('خمّن', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700)))),
          ] else
            ElevatedButton(onPressed: _restart,
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: Text('العب مجدداً', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700))),
          const Spacer(),
        ]))),
      ),
    );
  }
}
