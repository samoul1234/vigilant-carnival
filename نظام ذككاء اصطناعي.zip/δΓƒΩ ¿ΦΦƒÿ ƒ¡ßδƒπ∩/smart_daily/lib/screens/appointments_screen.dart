import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';
import '../theme/app_theme.dart';
import '../models/appointment.dart';

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  List<Appointment> _appointments = [];
  DateTime _selectedDay = DateTime.now();

  final List<LinearGradient> _gradients = [
    AppTheme.primaryGradient,
    AppTheme.accentGradient,
    AppTheme.greenGradient,
    AppTheme.purpleGradient,
    AppTheme.goldGradient,
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList('appointments') ?? [];
    setState(() {
      _appointments = data.map((e) => Appointment.fromMap(jsonDecode(e))).toList();
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'appointments',
      _appointments.map((e) => jsonEncode(e.toMap())).toList(),
    );
  }

  List<Appointment> get _todayAppointments {
    return _appointments.where((a) {
      return a.dateTime.year == _selectedDay.year &&
          a.dateTime.month == _selectedDay.month &&
          a.dateTime.day == _selectedDay.day;
    }).toList()
      ..sort((a, b) => a.dateTime.compareTo(b.dateTime));
  }

  void _showAddDialog([Appointment? existing]) {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    DateTime selectedDT = existing?.dateTime ?? _selectedDay.copyWith(
      hour: TimeOfDay.now().hour,
      minute: TimeOfDay.now().minute,
    );
    int colorIdx = existing?.colorIndex ?? 0;
    String category = existing?.category ?? 'عام';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          decoration: const BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.textSecondary.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                existing == null ? 'موعد جديد' : 'تعديل الموعد',
                style: GoogleFonts.cairo(
                  color: AppTheme.textPrimary,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 16),
              _buildTextField(titleCtrl, 'عنوان الموعد', Icons.title_rounded),
              const SizedBox(height: 12),
              _buildTextField(descCtrl, 'تفاصيل (اختياري)', Icons.notes_rounded),
              const SizedBox(height: 12),
              // Date & Time row
              Row(
                children: [
                  Expanded(
                    child: _buildInfoTile(
                      icon: Icons.calendar_today_rounded,
                      label: DateFormat('d MMM', 'ar').format(selectedDT),
                      onTap: () async {
                        final d = await showDatePicker(
                          context: ctx,
                          initialDate: selectedDT,
                          firstDate: DateTime.now().subtract(const Duration(days: 365)),
                          lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
                          builder: (c, child) => Theme(
                            data: ThemeData.dark().copyWith(
                              colorScheme: const ColorScheme.dark(primary: AppTheme.primary),
                            ),
                            child: child!,
                          ),
                        );
                        if (d != null) {
                          setModalState(() {
                            selectedDT = selectedDT.copyWith(year: d.year, month: d.month, day: d.day);
                          });
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildInfoTile(
                      icon: Icons.access_time_rounded,
                      label: DateFormat('HH:mm').format(selectedDT),
                      onTap: () async {
                        final t = await showTimePicker(
                          context: ctx,
                          initialTime: TimeOfDay.fromDateTime(selectedDT),
                          builder: (c, child) => Theme(
                            data: ThemeData.dark().copyWith(
                              colorScheme: const ColorScheme.dark(primary: AppTheme.primary),
                            ),
                            child: child!,
                          ),
                        );
                        if (t != null) {
                          setModalState(() {
                            selectedDT = selectedDT.copyWith(hour: t.hour, minute: t.minute);
                          });
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Color picker
              Text('اللون', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
              const SizedBox(height: 8),
              Row(
                children: List.generate(_gradients.length, (i) {
                  return GestureDetector(
                    onTap: () => setModalState(() => colorIdx = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 10),
                      width: colorIdx == i ? 36 : 28,
                      height: colorIdx == i ? 36 : 28,
                      decoration: BoxDecoration(
                        gradient: _gradients[i],
                        shape: BoxShape.circle,
                        border: colorIdx == i
                            ? Border.all(color: Colors.white, width: 2.5)
                            : null,
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (titleCtrl.text.trim().isEmpty) return;
                    final appt = Appointment(
                      id: existing?.id ?? const Uuid().v4(),
                      title: titleCtrl.text.trim(),
                      description: descCtrl.text.trim(),
                      dateTime: selectedDT,
                      category: category,
                      colorIndex: colorIdx,
                    );
                    setState(() {
                      if (existing != null) {
                        final idx = _appointments.indexWhere((a) => a.id == existing.id);
                        if (idx != -1) _appointments[idx] = appt;
                      } else {
                        _appointments.add(appt);
                      }
                    });
                    _save();
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: AppTheme.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Text(
                    existing == null ? 'إضافة الموعد' : 'حفظ التعديلات',
                    style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController ctrl, String hint, IconData icon) {
    return TextField(
      controller: ctrl,
      style: GoogleFonts.cairo(color: AppTheme.textPrimary),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.cairo(color: AppTheme.textSecondary),
        prefixIcon: Icon(icon, color: AppTheme.primary, size: 20),
        filled: true,
        fillColor: AppTheme.bgCard2,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }

  Widget _buildInfoTile({required IconData icon, required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.bgCard2,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.primary, size: 18),
            const SizedBox(width: 8),
            Text(label, style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = _todayAppointments;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.bgDark, Color(0xFF0D1230)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // App bar
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'مواعيدي',
                      style: GoogleFonts.cairo(
                        color: AppTheme.textPrimary,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${today.length} موعد',
                        style: GoogleFonts.cairo(color: AppTheme.primary, fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 500.ms),

              const SizedBox(height: 16),

              // Week strip
              _WeekStrip(
                selected: _selectedDay,
                onSelect: (d) => setState(() => _selectedDay = d),
              ),

              const SizedBox(height: 20),

              // Appointments list
              Expanded(
                child: today.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.event_available_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.4)),
                            const SizedBox(height: 12),
                            Text(
                              'لا توجد مواعيد اليوم',
                              style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 16),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: today.length,
                        itemBuilder: (ctx, i) {
                          final a = today[i];
                          return _AppointmentCard(
                            appointment: a,
                            gradient: _gradients[a.colorIndex % _gradients.length],
                            onToggle: () {
                              setState(() => a.isDone = !a.isDone);
                              _save();
                            },
                            onEdit: () => _showAddDialog(a),
                            onDelete: () {
                              setState(() => _appointments.removeWhere((x) => x.id == a.id));
                              _save();
                            },
                          ).animate().fadeIn(delay: Duration(milliseconds: i * 80), duration: 400.ms).slideX(begin: 0.2);
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(),
        backgroundColor: AppTheme.primary,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: Text('موعد جديد', style: GoogleFonts.cairo(color: Colors.white, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _WeekStrip extends StatelessWidget {
  final DateTime selected;
  final ValueChanged<DateTime> onSelect;

  const _WeekStrip({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final days = List.generate(14, (i) => today.subtract(Duration(days: 3)).add(Duration(days: i)));
    final dayNames = ['أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'];

    return SizedBox(
      height: 80,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: days.length,
        itemBuilder: (ctx, i) {
          final d = days[i];
          final isSelected = d.day == selected.day && d.month == selected.month;
          final isToday = d.day == today.day && d.month == today.month;

          return GestureDetector(
            onTap: () => onSelect(d),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: const EdgeInsets.symmetric(horizontal: 5),
              width: 52,
              decoration: BoxDecoration(
                gradient: isSelected ? AppTheme.primaryGradient : null,
                color: isSelected ? null : AppTheme.bgCard,
                borderRadius: BorderRadius.circular(16),
                border: isToday && !isSelected
                    ? Border.all(color: AppTheme.primary.withOpacity(0.5), width: 1.5)
                    : null,
                boxShadow: isSelected
                    ? [BoxShadow(color: AppTheme.primary.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 4))]
                    : null,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    dayNames[d.weekday % 7],
                    style: GoogleFonts.cairo(
                      color: isSelected ? Colors.white : AppTheme.textSecondary,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${d.day}',
                    style: GoogleFonts.cairo(
                      color: isSelected ? Colors.white : AppTheme.textPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _AppointmentCard extends StatelessWidget {
  final Appointment appointment;
  final LinearGradient gradient;
  final VoidCallback onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _AppointmentCard({
    required this.appointment,
    required this.gradient,
    required this.onToggle,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(appointment.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Icon(Icons.delete_rounded, color: Colors.red, size: 28),
      ),
      onDismissed: (_) => onDelete(),
      child: GestureDetector(
        onTap: onEdit,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: gradient.colors.first.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 4,
                height: 50,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      appointment.title,
                      style: GoogleFonts.cairo(
                        color: appointment.isDone
                            ? AppTheme.textSecondary
                            : AppTheme.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        decoration: appointment.isDone ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    if (appointment.description.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        appointment.description,
                        style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.access_time_rounded, size: 13, color: AppTheme.primary),
                        const SizedBox(width: 4),
                        Text(
                          DateFormat('HH:mm').format(appointment.dateTime),
                          style: GoogleFonts.cairo(color: AppTheme.primary, fontSize: 12, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onToggle,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    gradient: appointment.isDone ? AppTheme.greenGradient : null,
                    border: appointment.isDone ? null : Border.all(color: AppTheme.textSecondary, width: 2),
                    shape: BoxShape.circle,
                  ),
                  child: appointment.isDone
                      ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                      : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
