import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';
import '../theme/app_theme.dart';
import '../models/alarm.dart';

class StudyScreen extends StatefulWidget {
  const StudyScreen({super.key});
  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  List<Alarm> _studyAlarms = [];

  final List<String> _subjects = ['رياضيات', 'علوم', 'عربي', 'إنجليزي', 'تاريخ', 'جغرافيا', 'فيزياء', 'كيمياء', 'أحياء', 'أخرى'];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList('study_alarms') ?? [];
    setState(() { _studyAlarms = data.map((e) => Alarm.fromMap(jsonDecode(e))).toList(); });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('study_alarms', _studyAlarms.map((e) => jsonEncode(e.toMap())).toList());
  }

  void _showAddDialog([Alarm? existing]) {
    TimeOfDay selectedTime = existing?.time ?? TimeOfDay.now();
    String subject = existing?.subject ?? _subjects[0];
    final labelCtrl = TextEditingController(text: existing?.label ?? '');
    List<bool> repeatDays = List.from(existing?.repeatDays ?? List.filled(7, false));
    final dayLabels = ['أ', 'إ', 'ث', 'أر', 'خ', 'ج', 'س'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => Container(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom + 20, top: 20, left: 20, right: 20),
          decoration: const BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.textSecondary.withOpacity(0.4), borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 20),
              Text(existing == null ? 'منبه مذاكرة جديد' : 'تعديل المنبه',
                  style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              // Time
              GestureDetector(
                onTap: () async {
                  final t = await showTimePicker(context: ctx, initialTime: selectedTime,
                    builder: (c, child) => Theme(data: ThemeData.dark().copyWith(colorScheme: const ColorScheme.dark(primary: AppTheme.gold)), child: child!));
                  if (t != null) setModal(() => selectedTime = t);
                },
                child: Container(
                  width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(gradient: AppTheme.goldGradient, borderRadius: BorderRadius.circular(20)),
                  child: Center(child: Text(
                    '${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}',
                    style: GoogleFonts.cairo(color: Colors.white, fontSize: 52, fontWeight: FontWeight.w800, height: 1),
                  )),
                ),
              ),
              const SizedBox(height: 16),
              // Subject dropdown
              Text('المادة', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(color: AppTheme.bgCard2, borderRadius: BorderRadius.circular(14)),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: subject,
                    isExpanded: true,
                    dropdownColor: AppTheme.bgCard,
                    style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 15),
                    items: _subjects.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                    onChanged: (v) { if (v != null) setModal(() => subject = v); },
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: labelCtrl,
                style: GoogleFonts.cairo(color: AppTheme.textPrimary),
                decoration: InputDecoration(
                  hintText: 'ملاحظة (اختياري)',
                  hintStyle: GoogleFonts.cairo(color: AppTheme.textSecondary),
                  prefixIcon: const Icon(Icons.notes_rounded, color: AppTheme.gold, size: 20),
                  filled: true, fillColor: AppTheme.bgCard2,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 16),
              Text('التكرار', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(7, (i) => GestureDetector(
                  onTap: () => setModal(() => repeatDays[i] = !repeatDays[i]),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      gradient: repeatDays[i] ? AppTheme.goldGradient : null,
                      color: repeatDays[i] ? null : AppTheme.bgCard2,
                      shape: BoxShape.circle,
                    ),
                    child: Center(child: Text(dayLabels[i], style: GoogleFonts.cairo(color: repeatDays[i] ? Colors.white : AppTheme.textSecondary, fontSize: 13, fontWeight: FontWeight.w600))),
                  ),
                )),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    final alarm = Alarm(
                      id: existing?.id ?? const Uuid().v4(),
                      label: labelCtrl.text.trim().isEmpty ? subject : labelCtrl.text.trim(),
                      time: selectedTime,
                      repeatDays: repeatDays,
                      type: 'study',
                      subject: subject,
                    );
                    setState(() {
                      if (existing != null) {
                        final idx = _studyAlarms.indexWhere((a) => a.id == existing.id);
                        if (idx != -1) _studyAlarms[idx] = alarm;
                      } else {
                        _studyAlarms.add(alarm);
                      }
                    });
                    _save();
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: AppTheme.gold,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Text(existing == null ? 'إضافة المنبه' : 'حفظ', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.black)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [AppTheme.bgDark, Color(0xFF0D1230)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('منبهات المذاكرة 📚', style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.w800)),
                      Text('نظم جدول مذاكرتك', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
                    ]),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12)),
                      child: Text('${_studyAlarms.where((a) => a.isActive).length} نشط',
                          style: GoogleFonts.cairo(color: AppTheme.gold, fontSize: 13, fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 500.ms),

              // Stats row
              if (_studyAlarms.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      _StatCard(label: 'إجمالي', value: '${_studyAlarms.length}', gradient: AppTheme.goldGradient),
                      const SizedBox(width: 12),
                      _StatCard(label: 'نشط', value: '${_studyAlarms.where((a) => a.isActive).length}', gradient: AppTheme.greenGradient),
                      const SizedBox(width: 12),
                      _StatCard(label: 'مواد', value: '${_studyAlarms.map((a) => a.subject).toSet().length}', gradient: AppTheme.primaryGradient),
                    ],
                  ),
                ).animate().fadeIn(delay: 200.ms),

              const SizedBox(height: 16),

              Expanded(
                child: _studyAlarms.isEmpty
                    ? Center(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.school_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.3)),
                          const SizedBox(height: 12),
                          Text('لا توجد منبهات مذاكرة', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 16)),
                          const SizedBox(height: 8),
                          Text('أضف منبهاً لتنظيم مذاكرتك', style: GoogleFonts.cairo(color: AppTheme.textSecondary.withOpacity(0.6), fontSize: 13)),
                        ]),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: _studyAlarms.length,
                        itemBuilder: (ctx, i) {
                          final a = _studyAlarms[i];
                          return _StudyAlarmCard(
                            alarm: a,
                            onToggle: () { setState(() => a.isActive = !a.isActive); _save(); },
                            onEdit: () => _showAddDialog(a),
                            onDelete: () { setState(() => _studyAlarms.removeWhere((x) => x.id == a.id)); _save(); },
                          ).animate().fadeIn(delay: Duration(milliseconds: i * 80), duration: 400.ms).slideX(begin: 0.2);
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(),
        backgroundColor: AppTheme.gold,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_alarm_rounded),
        label: Text('منبه مذاكرة', style: GoogleFonts.cairo(fontWeight: FontWeight.w700, color: Colors.black)),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final LinearGradient gradient;
  const _StatCard({required this.label, required this.value, required this.gradient});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: gradient.colors.first.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))]),
        child: Column(children: [
          Text(value, style: GoogleFonts.cairo(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
          Text(label, style: GoogleFonts.cairo(color: Colors.white.withOpacity(0.85), fontSize: 12)),
        ]),
      ),
    );
  }
}

class _StudyAlarmCard extends StatelessWidget {
  final Alarm alarm;
  final VoidCallback onToggle, onEdit, onDelete;
  const _StudyAlarmCard({required this.alarm, required this.onToggle, required this.onEdit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final dayLabels = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    final activeDays = alarm.repeatDays.asMap().entries.where((e) => e.value).map((e) => dayLabels[e.key]).join('، ');

    return Dismissible(
      key: Key(alarm.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
        child: const Icon(Icons.delete_rounded, color: Colors.red, size: 28),
      ),
      onDismissed: (_) => onDelete(),
      child: GestureDetector(
        onTap: onEdit,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 300),
          opacity: alarm.isActive ? 1.0 : 0.5,
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: alarm.isActive ? AppTheme.gold.withOpacity(0.3) : Colors.transparent, width: 1),
            ),
            child: Row(
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(gradient: AppTheme.goldGradient, borderRadius: BorderRadius.circular(14)),
                  child: Center(child: Text(alarm.subject.isNotEmpty ? alarm.subject[0] : '📚',
                      style: GoogleFonts.cairo(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w800))),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${alarm.time.hour.toString().padLeft(2, '0')}:${alarm.time.minute.toString().padLeft(2, '0')}',
                        style: GoogleFonts.cairo(color: alarm.isActive ? AppTheme.textPrimary : AppTheme.textSecondary, fontSize: 28, fontWeight: FontWeight.w800, height: 1)),
                    Text(alarm.subject, style: GoogleFonts.cairo(color: AppTheme.gold, fontSize: 14, fontWeight: FontWeight.w600)),
                    if (alarm.label != alarm.subject && alarm.label.isNotEmpty)
                      Text(alarm.label, style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 12)),
                    if (activeDays.isNotEmpty)
                      Text(activeDays, style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 11)),
                  ]),
                ),
                Switch(value: alarm.isActive, onChanged: (_) => onToggle(), activeColor: AppTheme.gold, activeTrackColor: AppTheme.gold.withOpacity(0.3)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
