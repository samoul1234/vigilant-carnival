import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../theme/app_theme.dart';

class StopwatchScreen extends StatefulWidget {
  const StopwatchScreen({super.key});

  @override
  State<StopwatchScreen> createState() => _StopwatchScreenState();
}

class _StopwatchScreenState extends State<StopwatchScreen> with TickerProviderStateMixin {
  Timer? _timer;
  int _elapsed = 0; // milliseconds
  bool _running = false;
  bool _isCountdown = false;
  int _countdownTarget = 0; // ms
  int _countdownRemaining = 0;
  final List<int> _laps = [];

  // Countdown presets in minutes
  final List<Map<String, dynamic>> _presets = [
    {'label': '1 دقيقة', 'minutes': 1},
    {'label': '5 دقائق', 'minutes': 5},
    {'label': '10 دقائق', 'minutes': 10},
    {'label': '15 دقيقة', 'minutes': 15},
    {'label': '25 دقيقة', 'minutes': 25},
    {'label': '30 دقيقة', 'minutes': 30},
    {'label': '45 دقيقة', 'minutes': 45},
    {'label': '60 دقيقة', 'minutes': 60},
  ];

  void _startStop() {
    if (_running) {
      _timer?.cancel();
      setState(() => _running = false);
    } else {
      _timer = Timer.periodic(const Duration(milliseconds: 10), (_) {
        setState(() {
          if (_isCountdown) {
            _countdownRemaining -= 10;
            if (_countdownRemaining <= 0) {
              _countdownRemaining = 0;
              _running = false;
              _timer?.cancel();
            }
          } else {
            _elapsed += 10;
          }
        });
      });
      setState(() => _running = true);
    }
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _running = false;
      _elapsed = 0;
      _laps.clear();
      if (_isCountdown) _countdownRemaining = _countdownTarget;
    });
  }

  void _lap() {
    if (_running && !_isCountdown) {
      setState(() => _laps.insert(0, _elapsed));
    }
  }

  void _setCountdown(int minutes) {
    _timer?.cancel();
    setState(() {
      _isCountdown = true;
      _running = false;
      _elapsed = 0;
      _laps.clear();
      _countdownTarget = minutes * 60 * 1000;
      _countdownRemaining = _countdownTarget;
    });
  }

  void _switchMode() {
    _timer?.cancel();
    setState(() {
      _isCountdown = !_isCountdown;
      _running = false;
      _elapsed = 0;
      _laps.clear();
      _countdownRemaining = _countdownTarget;
    });
  }

  String _formatTime(int ms) {
    final minutes = (ms ~/ 60000).toString().padLeft(2, '0');
    final seconds = ((ms % 60000) ~/ 1000).toString().padLeft(2, '0');
    final centis = ((ms % 1000) ~/ 10).toString().padLeft(2, '0');
    return '$minutes:$seconds.$centis';
  }

  String _formatLap(int ms) {
    final minutes = (ms ~/ 60000).toString().padLeft(2, '0');
    final seconds = ((ms % 60000) ~/ 1000).toString().padLeft(2, '0');
    final centis = ((ms % 1000) ~/ 10).toString().padLeft(2, '0');
    return '$minutes:$seconds.$centis';
  }

  double get _progress {
    if (!_isCountdown || _countdownTarget == 0) return 0;
    return 1 - (_countdownRemaining / _countdownTarget);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final displayMs = _isCountdown ? _countdownRemaining : _elapsed;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.bgDark, Color(0xFF0D1230)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'ستوب ووتش',
                      style: GoogleFonts.cairo(
                        color: AppTheme.textPrimary,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    GestureDetector(
                      onTap: _switchMode,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: _isCountdown ? AppTheme.greenGradient : AppTheme.primaryGradient,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _isCountdown ? 'عداد تنازلي' : 'ستوب ووتش',
                          style: GoogleFonts.cairo(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 500.ms),

              const SizedBox(height: 30),

              // Main timer circle
              CircularPercentIndicator(
                radius: 130,
                lineWidth: 10,
                percent: _isCountdown ? _progress.clamp(0.0, 1.0) : 0,
                backgroundColor: AppTheme.bgCard,
                linearGradient: const LinearGradient(
                  colors: [AppTheme.primary, AppTheme.secondary],
                ),
                circularStrokeCap: CircularStrokeCap.round,
                center: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _formatTime(displayMs),
                      style: GoogleFonts.robotoMono(
                        color: AppTheme.textPrimary,
                        fontSize: 36,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _running ? 'جاري...' : (_elapsed > 0 || _countdownRemaining != _countdownTarget ? 'متوقف' : 'جاهز'),
                      style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13),
                    ),
                  ],
                ),
              ).animate().fadeIn(delay: 200.ms, duration: 600.ms).scale(begin: const Offset(0.8, 0.8)),

              const SizedBox(height: 30),

              // Controls
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Lap / Reset
                  GestureDetector(
                    onTap: _running ? _lap : _reset,
                    child: Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: AppTheme.bgCard,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppTheme.textSecondary.withOpacity(0.3), width: 1.5),
                      ),
                      child: Icon(
                        _running ? Icons.flag_rounded : Icons.refresh_rounded,
                        color: AppTheme.textSecondary,
                        size: 26,
                      ),
                    ),
                  ),
                  const SizedBox(width: 24),
                  // Start/Stop
                  GestureDetector(
                    onTap: _startStop,
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        gradient: _running ? AppTheme.accentGradient : AppTheme.greenGradient,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: (_running ? AppTheme.accent : AppTheme.secondary).withOpacity(0.4),
                            blurRadius: 20,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Icon(
                        _running ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 36,
                      ),
                    ),
                  ).animate(target: _running ? 1 : 0).scale(begin: const Offset(1, 1), end: const Offset(0.95, 0.95)),
                  const SizedBox(width: 24),
                  // Placeholder
                  const SizedBox(width: 64, height: 64),
                ],
              ),

              const SizedBox(height: 20),

              // Countdown presets
              if (_isCountdown) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text('اختر مدة', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 44,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _presets.length,
                    itemBuilder: (ctx, i) {
                      final p = _presets[i];
                      final selected = _countdownTarget == (p['minutes'] as int) * 60 * 1000;
                      return GestureDetector(
                        onTap: () => _setCountdown(p['minutes'] as int),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            gradient: selected ? AppTheme.greenGradient : null,
                            color: selected ? null : AppTheme.bgCard,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            p['label'] as String,
                            style: GoogleFonts.cairo(
                              color: selected ? Colors.white : AppTheme.textSecondary,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],

              // Laps
              if (!_isCountdown && _laps.isNotEmpty) ...[
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: _laps.length,
                    itemBuilder: (ctx, i) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: AppTheme.bgCard,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'لفة ${_laps.length - i}',
                              style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 14),
                            ),
                            Text(
                              _formatLap(_laps[i]),
                              style: GoogleFonts.robotoMono(
                                color: AppTheme.primary,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ] else
                const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
