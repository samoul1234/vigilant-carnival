import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'dart:convert';
import '../theme/app_theme.dart';
import '../models/alarm.dart';

class AlarmsScreen extends StatefulWidget {
  const AlarmsScreen({super.key});

  @override
  State<AlarmsScreen> createState() => _AlarmsScreenState();
}

class _AlarmsScreenState extends State<AlarmsScreen> {
  List<Alarm> _alarms = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList('alarms') ?? [];
    setState(() {
      _alarms = data.map((e) => Alarm.fromMap(jsonDecode(e))).toList();
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('alarms', _alarms.map((e) => jsonEncode(e.toMap())).toList());
  }

  void _showAddDialog([Alarm? existing]) {
    final labelCtrl = TextEditingController(text: existing?.label ?? '');
    TimeOfDay selectedTime = existing?.time ?? TimeOfDay.now();
    List<bool> repeatDays = List.from(existing?.repeatDays ?? List.filled(7, false));
    final dayLabels = ['أ', 'إ', 'ث', 'أر', 'خ', 'ج', 'س'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          decoration: const BoxDecoration(
            color: AppTheme.bgCard,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.textSecondary.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                existing == null ? 'منبه جديد' : 'تعديل المنبه',
                style: GoogleFonts.cairo(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 16),
              // Time picker display
              GestureDetector(
                onTap: () async {
                  final t = await showTimePicker(
                    context: ctx,
                    initialTime: selectedTime,
                    builder: (c, child) => Theme(
                      data: ThemeData.dark().copyWith(
                        colorScheme: const ColorScheme.dark(primary: AppTheme.primary),
                      ),
                      child: child!,
                    ),
                  );
                  if (t != null) setModal(() => selectedTime = t);
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text(
                      '${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}',
                      style: GoogleFonts.cairo(
                        color: Colors.white,
                        fontSize: 52,
                        fontWeight: FontWeight.w800,
                        height: 1,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: labelCtrl,
                style: GoogleFonts.cairo(color: AppTheme.textPrimary),
                decoration: InputDecoration(
                  hintText: 'اسم المنبه',
                  hintStyle: GoogleFonts.cairo(color: AppTheme.textSecondary),
                  prefixIcon: const Icon(Icons.label_rounded, color: AppTheme.primary, size: 20),
                  filled: true,
                  fillColor: AppTheme.bgCard2,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('التكرار', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 13)),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(7, (i) {
                  return GestureDetector(
                    onTap: () => setModal(() => repeatDays[i] = !repeatDays[i]),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        gradient: repeatDays[i] ? AppTheme.primaryGradient : null,
                        color: repeatDays[i] ? null : AppTheme.bgCard2,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          dayLabels[i],
                          style: GoogleFonts.cairo(
                            color: repeatDays[i] ? Colors.white : AppTheme.textSecondary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    final alarm = Alarm(
                      id: existing?.id ?? const Uuid().v4(),
                      label: labelCtrl.text.trim().isEmpty ? 'منبه' : labelCtrl.text.trim(),
                      time: selectedTime,
                      repeatDays: repeatDays,
                    );
                    setState(() {
                      if (existing != null) {
                        final idx = _alarms.indexWhere((a) => a.id == existing.id);
                        if (idx != -1) _alarms[idx] = alarm;
                      } else {
                        _alarms.add(alarm);
                      }
                    });
                    _save();
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: AppTheme.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Text(
                    existing == null ? 'إضافة المنبه' : 'حفظ',
                    style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.bgDark, Color(0xFF0D1230)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'المنبهات',
                      style: GoogleFonts.cairo(
                        color: AppTheme.textPrimary,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: AppTheme.bgCard, borderRadius: BorderRadius.circular(12)),
                      child: Text(
                        '${_alarms.where((a) => a.isActive).length} نشط',
                        style: GoogleFonts.cairo(color: AppTheme.accent, fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ).animate().fadeIn(duration: 500.ms),
              Expanded(
                child: _alarms.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.alarm_off_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.3)),
                            const SizedBox(height: 12),
                            Text('لا توجد منبهات', style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 16)),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: _alarms.length,
                        itemBuilder: (ctx, i) {
                          final a = _alarms[i];
                          return _AlarmCard(
                            alarm: a,
                            onToggle: () {
                              setState(() => a.isActive = !a.isActive);
                              _save();
                            },
                            onEdit: () => _showAddDialog(a),
                            onDelete: () {
                              setState(() => _alarms.removeWhere((x) => x.id == a.id));
                              _save();
                            },
                          ).animate().fadeIn(delay: Duration(milliseconds: i * 80), duration: 400.ms).slideX(begin: 0.2);
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(),
        backgroundColor: AppTheme.accent,
        icon: const Icon(Icons.add_alarm_rounded, color: Colors.white),
        label: Text('منبه جديد', style: GoogleFonts.cairo(color: Colors.white, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _AlarmCard extends StatelessWidget {
  final Alarm alarm;
  final VoidCallback onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _AlarmCard({
    required this.alarm,
    required this.onToggle,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final dayLabels = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    final activeDays = alarm.repeatDays.asMap().entries.where((e) => e.value).map((e) => dayLabels[e.key]).join('، ');

    return Dismissible(
      key: Key(alarm.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
        child: const Icon(Icons.delete_rounded, color: Colors.red, size: 28),
      ),
      onDismissed: (_) => onDelete(),
      child: GestureDetector(
        onTap: onEdit,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 300),
          opacity: alarm.isActive ? 1.0 : 0.5,
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: alarm.isActive ? AppTheme.accent.withOpacity(0.3) : Colors.transparent,
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${alarm.time.hour.toString().padLeft(2, '0')}:${alarm.time.minute.toString().padLeft(2, '0')}',
                        style: GoogleFonts.cairo(
                          color: alarm.isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
                          fontSize: 36,
                          fontWeight: FontWeight.w800,
                          height: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        alarm.label,
                        style: GoogleFonts.cairo(color: AppTheme.textSecondary, fontSize: 14),
                      ),
                      if (activeDays.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          activeDays,
                          style: GoogleFonts.cairo(color: AppTheme.primary, fontSize: 12),
                        ),
                      ],
                    ],
                  ),
                ),
                Switch(
                  value: alarm.isActive,
                  onChanged: (_) => onToggle(),
                  activeColor: AppTheme.accent,
                  activeTrackColor: AppTheme.accent.withOpacity(0.3),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
