class Appointment {
  final String id;
  final String title;
  final String description;
  final DateTime dateTime;
  final String category;
  final int colorIndex;
  bool isDone;

  Appointment({
    required this.id,
    required this.title,
    this.description = '',
    required this.dateTime,
    this.category = 'عام',
    this.colorIndex = 0,
    this.isDone = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'dateTime': dateTime.toIso8601String(),
        'category': category,
        'colorIndex': colorIndex,
        'isDone': isDone,
      };

  factory Appointment.fromMap(Map<String, dynamic> map) => Appointment(
        id: map['id'],
        title: map['title'],
        description: map['description'] ?? '',
        dateTime: DateTime.parse(map['dateTime']),
        category: map['category'] ?? 'عام',
        colorIndex: map['colorIndex'] ?? 0,
        isDone: map['isDone'] ?? false,
      );
}
