import 'package:flutter/material.dart';

class Alarm {
  final String id;
  final String label;
  final TimeOfDay time;
  bool isActive;
  final List<bool> repeatDays; // Sun=0 .. Sat=6
  final String type; // 'alarm' or 'study'
  final String subject;

  Alarm({
    required this.id,
    required this.label,
    required this.time,
    this.isActive = true,
    List<bool>? repeatDays,
    this.type = 'alarm',
    this.subject = '',
  }) : repeatDays = repeatDays ?? List.filled(7, false);

  Map<String, dynamic> toMap() => {
        'id': id,
        'label': label,
        'hour': time.hour,
        'minute': time.minute,
        'isActive': isActive,
        'repeatDays': repeatDays,
        'type': type,
        'subject': subject,
      };

  factory Alarm.fromMap(Map<String, dynamic> map) => Alarm(
        id: map['id'],
        label: map['label'],
        time: TimeOfDay(hour: map['hour'], minute: map['minute']),
        isActive: map['isActive'] ?? true,
        repeatDays: List<bool>.from(map['repeatDays'] ?? List.filled(7, false)),
        type: map['type'] ?? 'alarm',
        subject: map['subject'] ?? '',
      );
}
